// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { AppProvider } from './src/contexts/AppContext';
import Navegacao from './src/navigation/Navegacao';

export default function App() {
  return (
    <NavigationContainer>
      <AppProvider>
        <Navegacao />
      </AppProvider>
    </NavigationContainer>
  );
}
