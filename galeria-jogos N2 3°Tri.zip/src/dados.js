// src/dados.js
// Catálogo estático de jogos da GG Store (não usamos API nem banco de dados externo).
// Apenas UM jogo tem destaque: true (ele aparece no card grande da vitrine).

export const jogos = [
  {
    id: '1',
    titulo: 'Neon Racers',
    preco: 129.9,
    genero: 'Corrida',
    descricao:
      'Corra por cidades futuristas iluminadas por neon em alta velocidade. Personalize o seu carro, desafie amigos em corridas online e desbloqueie novas pistas a cada vitória. Mais de 40 carros disponíveis e trilha sonora eletrônica original.',
    imagemCapa: 'https://placehold.co/400x500/7c3aed/ffffff.png?text=Neon+Racers',
    destaque: true,
  },
  {
    id: '2',
    titulo: 'Dragon Keep',
    preco: 89.9,
    genero: 'RPG',
    descricao:
      'Explore um reino medieval cheio de dragões, masmorras e segredos. Escolha a sua classe, forme um grupo de heróis e decida o destino do castelo em uma história com vários finais.',
    imagemCapa: 'https://placehold.co/400x500/b91c1c/ffffff.png?text=Dragon+Keep',
    destaque: false,
  },
  {
    id: '3',
    titulo: 'Ocean Quest',
    preco: 59.9,
    genero: 'Aventura',
    descricao:
      'Mergulhe nas profundezas do oceano em busca de tesouros perdidos. Resolva enigmas, descubra criaturas marinhas e explore naufrágios misteriosos em uma aventura relaxante para toda a família.',
    imagemCapa: 'https://placehold.co/400x500/0369a1/ffffff.png?text=Ocean+Quest',
    destaque: false,
  },
  {
    id: '4',
    titulo: 'Dark Mansion',
    preco: 49.9,
    genero: 'Terror',
    descricao:
      'Você ficou preso em uma mansão abandonada e precisa encontrar a saída antes do amanhecer. Use a lanterna com sabedoria, esconda-se dos perigos e descubra o que aconteceu com os antigos moradores.',
    imagemCapa: 'https://placehold.co/400x500/1f2937/ffffff.png?text=Dark+Mansion',
    destaque: false,
  },
  {
    id: '5',
    titulo: 'Super Goal 2026',
    preco: 199.9,
    genero: 'Esporte',
    descricao:
      'O simulador de futebol mais completo da temporada. Monte o seu time, dispute campeonatos nacionais e internacionais e jogue partidas online contra jogadores do mundo todo.',
    imagemCapa: 'https://placehold.co/400x500/15803d/ffffff.png?text=Super+Goal',
    destaque: false,
  },
  {
    id: '6',
    titulo: 'Tower Defenders',
    preco: 39.9,
    genero: 'Estratégia',
    descricao:
      'Construa torres, posicione os seus defensores e impeça que as ondas de inimigos cheguem ao seu reino. Mais de 60 fases com desafios cada vez maiores e vários níveis de dificuldade.',
    imagemCapa: 'https://placehold.co/400x500/c2410c/ffffff.png?text=Tower+Defenders',
    destaque: false,
  },
  {
    id: '7',
    titulo: 'Puzzle Planet',
    preco: 19.9,
    genero: 'Puzzle',
    descricao:
      'Viaje por planetas coloridos resolvendo quebra-cabeças criativos. Simples de aprender, difícil de largar: são mais de 200 fases para jogar no seu ritmo.',
    imagemCapa: 'https://placehold.co/400x500/db2777/ffffff.png?text=Puzzle+Planet',
    destaque: false,
  },
];
