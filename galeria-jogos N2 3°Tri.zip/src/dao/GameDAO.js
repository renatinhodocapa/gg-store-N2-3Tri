// src/dao/GameDAO.js
// Camada de acesso a dados (DAO): todas as chamadas ao AsyncStorage ficam aqui.
// Como o AsyncStorage só guarda strings, usamos JSON.stringify para gravar e JSON.parse para ler.
import AsyncStorage from '@react-native-async-storage/async-storage';

const CHAVE_FAVORITOS = '@ggstore:favoritos';
const CHAVE_PERFIL = '@ggstore:perfil';

// ----- Lista de Desejos (guarda só os IDs dos jogos) -----

export async function obterFavoritos() {
  try {
    const jsonValue = await AsyncStorage.getItem(CHAVE_FAVORITOS);
    return jsonValue != null ? JSON.parse(jsonValue) : [];
  } catch (e) {
    console.error('Erro ao ler favoritos', e);
    return [];
  }
}

export async function salvarFavoritos(listaDeIds) {
  try {
    const jsonValue = JSON.stringify(listaDeIds);
    await AsyncStorage.setItem(CHAVE_FAVORITOS, jsonValue);
  } catch (e) {
    console.error('Erro ao salvar favoritos', e);
  }
}

// ----- Perfil (nome de jogador e modo escuro) -----

export async function obterPerfil() {
  try {
    const jsonValue = await AsyncStorage.getItem(CHAVE_PERFIL);
    // Se ainda não existe perfil salvo, devolve um perfil padrão
    return jsonValue != null ? JSON.parse(jsonValue) : { nickname: '', modoEscuro: false };
  } catch (e) {
    console.error('Erro ao ler perfil', e);
    return { nickname: '', modoEscuro: false };
  }
}

export async function salvarPerfil(perfil) {
  try {
    const jsonValue = JSON.stringify(perfil);
    await AsyncStorage.setItem(CHAVE_PERFIL, jsonValue);
  } catch (e) {
    console.error('Erro ao salvar perfil', e);
  }
}
