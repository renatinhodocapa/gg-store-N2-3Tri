// src/contexts/AppContext.js
// Estado global do app (Context API): lista de desejos, nome de jogador e tema.
// Assim todas as telas acessam essas informações sem precisar passar por route.params.
import React, { createContext, useState, useEffect } from 'react';
import * as GameDAO from '../dao/GameDAO';

export const AppContext = createContext({});

const coresClaro = {
  fundo: '#f5f5f5',
  card: '#ffffff',
  texto: '#222222',
  textoSecundario: '#666666',
  borda: '#dddddd',
};

const coresEscuro = {
  fundo: '#121212',
  card: '#1e1e1e',
  texto: '#ffffff',
  textoSecundario: '#aaaaaa',
  borda: '#333333',
};

export function AppProvider({ children }) {
  const [favoritos, setFavoritos] = useState([]); // lista de IDs
  const [nickname, setNickname] = useState('');
  const [modoEscuro, setModoEscuro] = useState(false);

  // Quando o app abre, carrega os dados salvos no AsyncStorage
  useEffect(() => {
    async function carregarDados() {
      const ids = await GameDAO.obterFavoritos();
      const perfil = await GameDAO.obterPerfil();
      setFavoritos(ids);
      setNickname(perfil.nickname);
      setModoEscuro(perfil.modoEscuro);
    }
    carregarDados();
  }, []);

  // Adiciona o jogo na lista de desejos, ou remove se ele já estiver nela
  async function alternarFavorito(id) {
    let novaLista = [];
    if (favoritos.includes(id)) {
      novaLista = favoritos.filter(idFavorito => idFavorito !== id);
    } else {
      novaLista = [...favoritos, id];
    }
    setFavoritos(novaLista); // atualiza a tela
    await GameDAO.salvarFavoritos(novaLista); // grava no aparelho
  }

  // Chamada pelo botão "Salvar Configurações" da tela de Perfil
  async function salvarConfiguracoes(novoNickname, novoModoEscuro) {
    setNickname(novoNickname);
    setModoEscuro(novoModoEscuro);
    await GameDAO.salvarPerfil({ nickname: novoNickname, modoEscuro: novoModoEscuro });
  }

  // Escolhe a paleta de cores de acordo com o tema
  const cores = modoEscuro ? coresEscuro : coresClaro;

  return (
    <AppContext.Provider
      value={{ favoritos, alternarFavorito, nickname, modoEscuro, salvarConfiguracoes, cores }}
    >
      {children}
    </AppContext.Provider>
  );
}
