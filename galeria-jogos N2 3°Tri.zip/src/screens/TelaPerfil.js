// src/screens/TelaPerfil.js
// Tela 3: Perfil e Lista de Desejos (Wishlist)
import React, { useState, useEffect, useContext } from 'react';
import { View, Text, TextInput, Switch, Button, FlatList, StyleSheet, Alert, Platform } from 'react-native';
import { jogos } from '../dados';
import ItemWishlist from '../componentes/ItemWishlist';
import { AppContext } from '../contexts/AppContext';

export default function TelaPerfil() {
  const { favoritos, alternarFavorito, nickname, modoEscuro, salvarConfiguracoes, cores } =
    useContext(AppContext);

  // Estados locais do formulário (só valem de verdade depois de clicar em "Salvar")
  const [nicknameDigitado, setNicknameDigitado] = useState('');
  const [escuroSelecionado, setEscuroSelecionado] = useState(false);

  // Quando os dados salvos são carregados do AsyncStorage, preenche o formulário
  useEffect(() => {
    setNicknameDigitado(nickname);
    setEscuroSelecionado(modoEscuro);
  }, [nickname, modoEscuro]);

  // Pega somente os jogos que o usuário favoritou
  const jogosFavoritos = jogos.filter(jogo => favoritos.includes(jogo.id));

  async function salvar() {
    await salvarConfiguracoes(nicknameDigitado.trim(), escuroSelecionado);

    // Mensagem de sucesso (na web o Alert não funciona, por isso usamos Platform)
    if (Platform.OS === 'web') {
      alert('Configurações salvas com sucesso!');
    } else {
      Alert.alert('Sucesso!', 'Configurações salvas com sucesso!');
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: cores.fundo }]}>
      <View style={[styles.card, { backgroundColor: cores.card }]}>
        <Text style={[styles.secao, { color: cores.texto }]}>Configurações</Text>

        <Text style={[styles.label, { color: cores.texto }]}>Nome de Jogador:</Text>
        <TextInput
          style={[styles.input, { color: cores.texto, borderColor: cores.borda }]}
          placeholder="Digite seu nickname"
          placeholderTextColor={cores.textoSecundario}
          value={nicknameDigitado}
          onChangeText={setNicknameDigitado}
        />

        <View style={styles.linhaSwitch}>
          <Text style={[styles.label, { color: cores.texto }]}>Ativar Modo Escuro</Text>
          <Switch value={escuroSelecionado} onValueChange={setEscuroSelecionado} />
        </View>

        <Button title="Salvar Configurações" onPress={salvar} color="#7c3aed" />
      </View>

      <Text style={[styles.secao, { color: cores.texto }]}>Minha Lista de Desejos</Text>

      {jogosFavoritos.length === 0 ? (
        <Text style={[styles.vazio, { color: cores.textoSecundario }]}>
          Você ainda não favoritou nenhum jogo.
        </Text>
      ) : (
        <FlatList
          data={jogosFavoritos}
          renderItem={({ item }) => (
            <ItemWishlist jogo={item} onRemover={() => alternarFavorito(item.id)} />
          )}
          keyExtractor={item => item.id}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  card: {
    padding: 16,
    borderRadius: 10,
    marginBottom: 20,
  },
  secao: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    height: 45,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  linhaSwitch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  vazio: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
  },
});
