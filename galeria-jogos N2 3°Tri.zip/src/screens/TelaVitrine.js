// src/screens/TelaVitrine.js
// Tela 1: Vitrine (Home / Catálogo)
import React, { useContext } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { jogos } from '../dados';
import CardJogo from '../componentes/CardJogo';
import { AppContext } from '../contexts/AppContext';

export default function TelaVitrine({ navigation }) {
  const { cores, nickname } = useContext(AppContext);

  // Separa o jogo em destaque dos demais
  const jogoDestaque = jogos.find(jogo => jogo.destaque === true);
  const outrosJogos = jogos.filter(jogo => jogo.destaque === false);

  // Navega para a tela de detalhes passando o jogo como parâmetro
  function abrirDetalhes(jogo) {
    navigation.navigate('Detalhes', { jogo: jogo });
  }

  return (
    <View style={[styles.container, { backgroundColor: cores.fundo }]}>
      {nickname !== '' && (
        <Text style={[styles.saudacao, { color: cores.texto }]}>Olá, {nickname}!</Text>
      )}

      <Text style={[styles.secao, { color: cores.texto }]}>Jogo em destaque</Text>
      <CardJogo jogo={jogoDestaque} grande={true} onPress={() => abrirDetalhes(jogoDestaque)} />

      <Text style={[styles.secao, { color: cores.texto }]}>Mais jogos</Text>
      <FlatList
        data={outrosJogos}
        numColumns={2}
        renderItem={({ item }) => <CardJogo jogo={item} onPress={() => abrirDetalhes(item)} />}
        keyExtractor={item => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 6,
  },
  saudacao: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
    marginLeft: 10,
  },
  secao: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 10,
    marginLeft: 10,
  },
});
