// src/screens/TelaDetalhes.js
// Tela 2: Detalhes do Jogo
import React, { useContext } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { AppContext } from '../contexts/AppContext';

export default function TelaDetalhes({ route }) {
  // Recebe o jogo enviado pela tela da vitrine
  const { jogo } = route.params;
  const { favoritos, alternarFavorito, cores } = useContext(AppContext);

  // Verifica se este jogo já está na lista de desejos
  const favoritado = favoritos.includes(jogo.id);

  return (
    <ScrollView style={{ backgroundColor: cores.fundo }}>
      <Image source={{ uri: jogo.imagemCapa }} style={styles.capa} resizeMode="cover" />

      <View style={styles.conteudo}>
        <Text style={[styles.titulo, { color: cores.texto }]}>{jogo.titulo}</Text>
        <Text style={[styles.genero, { color: cores.textoSecundario }]}>Gênero: {jogo.genero}</Text>
        <Text style={styles.preco}>R$ {jogo.preco.toFixed(2).replace('.', ',')}</Text>

        <TouchableOpacity
          style={[styles.botao, favoritado && styles.botaoFavoritado]}
          onPress={() => alternarFavorito(jogo.id)}
        >
          <Text style={styles.textoBotao}>
            {favoritado ? '❤️ Na Lista de Desejos (tocar para remover)' : '🤍 Adicionar à Lista de Desejos'}
          </Text>
        </TouchableOpacity>

        <Text style={[styles.subtitulo, { color: cores.texto }]}>Sobre o jogo</Text>
        <Text style={[styles.descricao, { color: cores.texto }]}>{jogo.descricao}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  capa: {
    width: '100%',
    height: 350,
  },
  conteudo: {
    padding: 20,
  },
  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
  },
  genero: {
    fontSize: 16,
    marginTop: 4,
  },
  preco: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#16a34a',
    marginTop: 10,
  },
  botao: {
    backgroundColor: '#7c3aed',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  botaoFavoritado: {
    backgroundColor: '#dc2626',
  },
  textoBotao: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  subtitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 25,
  },
  descricao: {
    fontSize: 16,
    lineHeight: 24,
    marginTop: 8,
  },
});
