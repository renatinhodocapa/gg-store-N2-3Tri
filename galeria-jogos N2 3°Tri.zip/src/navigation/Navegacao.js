// src/navigation/Navegacao.js
// Navegação aninhada: Abas (Vitrine e Perfil) e, dentro da aba Vitrine, uma Pilha (Catálogo -> Detalhes).
import React, { useContext } from 'react';
import { Text } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import TelaVitrine from '../screens/TelaVitrine';
import TelaDetalhes from '../screens/TelaDetalhes';
import TelaPerfil from '../screens/TelaPerfil';
import { AppContext } from '../contexts/AppContext';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Pilha da aba "Vitrine": lista de jogos -> detalhes do jogo
function NavegacaoPilha() {
  const { cores } = useContext(AppContext);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: cores.card },
        headerTintColor: cores.texto,
      }}
    >
      <Stack.Screen name="Catalogo" component={TelaVitrine} options={{ title: 'GG Store' }} />
      <Stack.Screen name="Detalhes" component={TelaDetalhes} options={{ title: 'Detalhes do Jogo' }} />
    </Stack.Navigator>
  );
}

// Menu de abas na parte de baixo da tela
export default function Navegacao() {
  const { cores } = useContext(AppContext);

  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: cores.card },
        headerTintColor: cores.texto,
        tabBarStyle: { backgroundColor: cores.card },
        tabBarActiveTintColor: '#7c3aed',
      }}
    >
      <Tab.Screen
        name="Vitrine"
        component={NavegacaoPilha}
        options={{ headerShown: false, tabBarIcon: () => <Text>🎮</Text> }}
      />
      <Tab.Screen
        name="Perfil"
        component={TelaPerfil}
        options={{ title: 'Meu Perfil', tabBarIcon: () => <Text>👤</Text> }}
      />
    </Tab.Navigator>
  );
}
