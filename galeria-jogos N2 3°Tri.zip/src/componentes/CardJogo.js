// src/componentes/CardJogo.js
// Card de um jogo da vitrine. Se a prop "grande" for true, vira o card de destaque.
import React, { useContext } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { AppContext } from '../contexts/AppContext';

export default function CardJogo({ jogo, onPress, grande }) {
  const { cores } = useContext(AppContext);

  return (
    <TouchableOpacity
      style={[styles.card, grande && styles.cardGrande, { backgroundColor: cores.card }]}
      onPress={onPress}
    >
      <Image
        source={{ uri: jogo.imagemCapa }}
        style={[styles.capa, grande && styles.capaGrande]}
        resizeMode="cover"
      />
      <View style={styles.info}>
        <Text style={[styles.titulo, { color: cores.texto }]}>{jogo.titulo}</Text>
        <Text style={[styles.genero, { color: cores.textoSecundario }]}>{jogo.genero}</Text>
        <Text style={styles.preco}>R$ {jogo.preco.toFixed(2).replace('.', ',')}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    margin: 6,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  cardGrande: {
    flex: 0,
    margin: 10,
  },
  capa: {
    width: '100%',
    height: 140,
  },
  capaGrande: {
    height: 180,
  },
  info: {
    padding: 10,
  },
  titulo: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  genero: {
    fontSize: 13,
    marginTop: 2,
  },
  preco: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#16a34a',
    marginTop: 6,
  },
});
