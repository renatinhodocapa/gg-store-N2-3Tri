// src/componentes/ItemWishlist.js
// Item da Lista de Desejos (tela de Perfil): capa pequena, dados do jogo e botão de remover.
import React, { useContext } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { AppContext } from '../contexts/AppContext';

export default function ItemWishlist({ jogo, onRemover }) {
  const { cores } = useContext(AppContext);

  return (
    <View style={[styles.container, { backgroundColor: cores.card }]}>
      <Image source={{ uri: jogo.imagemCapa }} style={styles.capa} resizeMode="cover" />
      <View style={styles.info}>
        <Text style={[styles.titulo, { color: cores.texto }]}>{jogo.titulo}</Text>
        <Text style={{ color: cores.textoSecundario }}>{jogo.genero}</Text>
        <Text style={styles.preco}>R$ {jogo.preco.toFixed(2).replace('.', ',')}</Text>
      </View>
      <TouchableOpacity style={styles.botaoRemover} onPress={onRemover}>
        <Text style={styles.textoBotao}>Remover</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    marginVertical: 5,
    borderRadius: 8,
  },
  capa: {
    width: 50,
    height: 65,
    borderRadius: 6,
  },
  info: {
    flex: 1,
    marginHorizontal: 12,
  },
  titulo: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  preco: {
    color: '#16a34a',
    fontWeight: 'bold',
    marginTop: 2,
  },
  botaoRemover: {
    backgroundColor: '#dc3545',
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  textoBotao: {
    color: 'white',
    fontWeight: 'bold',
  },
});
